WITH diagnosis_data AS (
    SELECT DISTINCT 
        unnest(all_diag_all) AS diagnosis_code
    FROM {{ ref('src_ecg_recordings') }}
    WHERE all_diag_all IS NOT NULL AND array_length(all_diag_all, 1) > 0
    
    UNION ALL
    
    SELECT 'No Diagnosis' AS diagnosis_code

    UNION ALL

    SELECT DISTINCT 
        unnest(ed_diag_ed) AS diagnosis_code
    FROM {{ ref('src_ed_visits') }}
    WHERE ed_diag_ed IS NOT NULL AND array_length(ed_diag_ed, 1) > 0
)

-- from this website: https://www.medicalbillingandcoding.org/icd-10-cm/
SELECT DISTINCT
    diagnosis_code,
    CASE
        WHEN diagnosis_code = 'No Diagnosis' THEN 'No Diagnosis'
        WHEN LEFT(diagnosis_code, 1) = 'A' OR LEFT(diagnosis_code, 1) = 'B' THEN 'Infections and Parasitic' 
        WHEN LEFT(diagnosis_code, 1) = 'C' THEN 'Neoplasms'
        WHEN LEFT(diagnosis_code, 1) = 'D' AND
            -- Check if the second and third characters are digits before casting
            SUBSTRING(diagnosis_code, 2, 1) ~ '^[0-9]+$' 
            AND CAST(SUBSTRING(diagnosis_code, 2, 1) AS INT) <= 4 THEN 'Neoplasms'
        WHEN LEFT(diagnosis_code, 1) = 'D' AND
            SUBSTRING(diagnosis_code, 2, 1) ~ '^[0-9]+$' 
            AND CAST(SUBSTRING(diagnosis_code, 2, 1) AS INT) BETWEEN 5 AND 9 THEN 'Blood and Immune System'
        WHEN LEFT(diagnosis_code, 1) = 'E' THEN 'Endocrine, Nutritional and Metabolic'
        WHEN LEFT(diagnosis_code, 1) = 'F' THEN 'Mental, Behavioral and Neurodevelopmental' 
        WHEN LEFT(diagnosis_code, 1) = 'G' THEN 'Nervous System'
        WHEN LEFT(diagnosis_code, 1) = 'H' AND
            SUBSTRING(diagnosis_code, 2, 1) ~ '^[0-9]+$' 
            AND CAST(SUBSTRING(diagnosis_code, 2, 1) AS INT) < 6 THEN 'Eye and Adnexa'
        WHEN LEFT(diagnosis_code, 1) = 'H' AND
            SUBSTRING(diagnosis_code, 2, 1) ~ '^[0-9]+$' 
            AND CAST(SUBSTRING(diagnosis_code, 2, 1) AS INT) BETWEEN 6 AND 9 THEN 'Ear and Mastoid'
        WHEN LEFT(diagnosis_code, 1) = 'I' THEN 'Circulatory System' 
        WHEN LEFT(diagnosis_code, 1) = 'J' THEN 'Respiratory System'
        WHEN LEFT(diagnosis_code, 1) = 'K' THEN 'Digestive System' 
        WHEN LEFT(diagnosis_code, 1) = 'L' THEN 'Skin and Subcutaneous Tissue'
        WHEN LEFT(diagnosis_code, 1) = 'M' THEN 'Musculoskeletal System and Connective Tissue'
        WHEN LEFT(diagnosis_code, 1) = 'N' THEN 'Genitourinary System'
        WHEN LEFT(diagnosis_code, 1) = 'O' THEN 'Pregnancy, Childbirth, and Puerperium' 
        WHEN LEFT(diagnosis_code, 1) = 'P' THEN 'Certain Conditions Originating in the Perinatal Period'
        WHEN LEFT(diagnosis_code, 1) = 'Q' THEN 'Congenital Malformations, Deformations and Chromosomal Abnormalities' 
        WHEN LEFT(diagnosis_code, 1) = 'R' THEN 'Abnormal Clinical and Laboratory Findings'
        WHEN LEFT(diagnosis_code, 1) = 'S' OR LEFT(diagnosis_code, 1) = 'T' THEN 'Injury, Poisoning, and External Causes'
        WHEN LEFT(diagnosis_code, 1) = 'V' OR LEFT(diagnosis_code, 1) = 'W' OR LEFT(diagnosis_code, 1) = 'X' OR LEFT(diagnosis_code, 1) = 'Y' THEN 'External Causes of Morbidity' 
        WHEN LEFT(diagnosis_code, 1) = 'Z' THEN 'Factors Influencing Health Status and Contact with Health Services'
        ELSE 'Unknown Diagnosis'
    END AS diagnosis_category

FROM diagnosis_data