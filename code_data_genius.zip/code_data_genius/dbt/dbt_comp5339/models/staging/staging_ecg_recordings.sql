WITH ecg_recordings_data AS (
    SELECT
        study_id,
        file_name,
        ecg_time,
        COALESCE(age, -1) AS age,
        COALESCE(anchor_age, -1) AS anchor_age,
        CASE
            WHEN all_diag_all IS NULL OR array_length(all_diag_all, 1) = 0 THEN 0
            ELSE array_length(all_diag_all, 1)
        END AS num_all_diag,
        ecg_no_within_stay,
        subject_id,
        hosp_hadm_id,
        ed_hadm_id,
        ed_stay_id
    FROM {{ ref('src_ecg_recordings') }}
)

SELECT
    study_id,
    file_name,
    ecg_time,
    age,
    anchor_age,
    num_all_diag,
    ecg_no_within_stay,
    subject_id,
    hosp_hadm_id,
    ed_hadm_id,
    ed_stay_id
FROM ecg_recordings_data 