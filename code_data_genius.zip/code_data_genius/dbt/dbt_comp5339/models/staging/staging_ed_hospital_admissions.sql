WITH ed_hospital_data AS (
    SELECT
        ed_hadm_id,
        ed_stay_id,
        subject_id,
        ecg_no_within_stay,
        CASE
            WHEN ed_diag_hosp IS NULL OR array_length(ed_diag_hosp, 1) = 0 THEN ARRAY['No Diagnosis']
            ELSE ed_diag_hosp
        END AS ed_diag_hosp
    FROM {{ ref('src_ed_hospital_admissions') }}
),
unnested_data AS (
    SELECT
        ed_hadm_id,
        ed_stay_id,
        subject_id,
        ecg_no_within_stay,
        unnest(ed_diag_hosp) AS ed_hospital_diagnosis_code
    FROM ed_hospital_data
)

SELECT
    ed_hadm_id,
    ed_stay_id,
    subject_id,
    ecg_no_within_stay,
    ed_hospital_diagnosis_code
FROM unnested_data
