WITH hospital_data AS (
    SELECT
        hosp_hadm_id,
        subject_id,
        ecg_no_within_stay,
        CASE
            WHEN hosp_diag_hosp IS NULL OR array_length(hosp_diag_hosp, 1) = 0 THEN ARRAY['No Diagnosis']
            ELSE hosp_diag_hosp
        END AS hosp_diag_hosp
    FROM {{ ref('src_hospital_admissions') }}
),
unnested_data AS (
    SELECT
        hosp_hadm_id,
        subject_id,
        ecg_no_within_stay,
        unnest(hosp_diag_hosp) AS hospital_diagnosis_code
    FROM hospital_data
)

SELECT
    hosp_hadm_id,
    subject_id,
    ecg_no_within_stay,
    hospital_diagnosis_code
FROM unnested_data