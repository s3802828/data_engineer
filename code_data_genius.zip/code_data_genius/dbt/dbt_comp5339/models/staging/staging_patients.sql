WITH patient_data AS (
    SELECT
        subject_id,
        UPPER(gender) AS gender,  -- Standardizing gender values (e.g., 'M', 'F')
        anchor_year,
        CASE WHEN dod IS NOT NULL THEN TO_DATE(dod, 'YYYY-MM-DD') ELSE NULL END AS dod
    FROM {{ ref('src_patients') }}
)

SELECT
    subject_id,
    gender,
    anchor_year,
    dod
FROM patient_data
