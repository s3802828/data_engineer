WITH ed_data AS (
    SELECT
        ed_stay_id,
        subject_id,
        ecg_no_within_stay,
        CASE
            WHEN ed_diag_ed IS NULL OR array_length(ed_diag_ed, 1) = 0 THEN ARRAY['No Diagnosis']
            ELSE ed_diag_ed
        END AS ed_diag_ed
    FROM {{ ref('src_ed_visits') }}
),
unnested_data AS (
    SELECT
        ed_stay_id,
        subject_id,
        ecg_no_within_stay,
        unnest(ed_diag_ed) AS ed_diagnosis_code
    FROM ed_data
)

SELECT
    ed_stay_id,
    subject_id,
    ecg_no_within_stay,
    ed_diagnosis_code
FROM unnested_data