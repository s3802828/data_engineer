WITH raw_data_1 AS (
    SELECT
        SUM(COALESCE(cardinality(ed_diag_hosp), 0)) AS total_items_in_array
    FROM {{ ref('src_ed_hospital_admissions') }}
),
transformed_data_1 AS (
    SELECT
        COUNT(1) AS total_unnested_rows
    FROM {{ ref('dim_ed_hospital_admissions') }}
    WHERE ed_hospital_diagnosis_code != 'No Diagnosis'
),
raw_data_2 AS (
    SELECT
        SUM(COALESCE(cardinality(ed_diag_ed), 0)) AS total_items_in_array
    FROM {{ ref('src_ed_visits') }}
),
transformed_data_2 AS (
    SELECT
        COUNT(1) AS total_unnested_rows
    FROM {{ ref('dim_ed_visits') }}
    WHERE ed_diagnosis_code != 'No Diagnosis'
),
raw_data_3 AS (
    SELECT
        SUM(COALESCE(cardinality(hosp_diag_hosp), 0)) AS total_items_in_array
    FROM {{ ref('src_hospital_admissions') }}
),
transformed_data_3 AS (
    SELECT
        COUNT(1) AS total_unnested_rows
    FROM {{ ref('dim_hospital_admissions') }}
    WHERE hospital_diagnosis_code != 'No Diagnosis'
)

SELECT
    'ed_hospital_admissions' AS table_name,
    raw_data_1.total_items_in_array,
    transformed_data_1.total_unnested_rows,
    CASE
        WHEN raw_data_1.total_items_in_array = transformed_data_1.total_unnested_rows THEN 'PASS'
        ELSE 'FAIL'
    END AS validation_status
FROM raw_data_1, transformed_data_1

UNION ALL

SELECT
    'ed_visits' AS table_name,
    raw_data_2.total_items_in_array,
    transformed_data_2.total_unnested_rows,
    CASE
        WHEN raw_data_2.total_items_in_array = transformed_data_2.total_unnested_rows THEN 'PASS'
        ELSE 'FAIL'
    END AS validation_status
FROM raw_data_2, transformed_data_2

UNION ALL

SELECT
    'hospital_admissions' AS table_name,
    raw_data_3.total_items_in_array,
    transformed_data_3.total_unnested_rows,
    CASE
        WHEN raw_data_3.total_items_in_array = transformed_data_3.total_unnested_rows THEN 'PASS'
        ELSE 'FAIL'
    END AS validation_status
FROM raw_data_3, transformed_data_3