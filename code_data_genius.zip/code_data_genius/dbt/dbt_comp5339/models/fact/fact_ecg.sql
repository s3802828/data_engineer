{{
    config(
        materialized = 'table',
        unique_key = 'event_id',
        schema = 'warehouse'
    )
}}

SELECT *
FROM {{ ref('staging_ecg_recordings') }}