WITH raw_hospital_admissions AS (
    SELECT * 
    FROM {{ source('import', 'hospital_admissions') }}
)

SELECT * 
FROM raw_hospital_admissions
