WITH raw_ed_hospital_admissions AS (
    SELECT * 
    FROM {{ source('import', 'ed_hospital_admissions') }}
)

SELECT * 
FROM raw_ed_hospital_admissions
