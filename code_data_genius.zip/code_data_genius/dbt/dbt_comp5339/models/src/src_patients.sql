WITH raw_patients AS (
    SELECT * 
    FROM {{ source('import', 'patients') }}
)

SELECT * 
FROM raw_patients
