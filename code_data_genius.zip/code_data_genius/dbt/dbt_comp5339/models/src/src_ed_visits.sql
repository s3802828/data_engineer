WITH raw_ed_visits AS (
    SELECT * 
    FROM {{ source('import', 'ed_visits') }}
)

SELECT * 
FROM raw_ed_visits
