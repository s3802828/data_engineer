WITH raw_ecg_recordings AS (
    SELECT * 
    FROM {{ source('import', 'ecg_recordings') }}
)

SELECT * 
FROM raw_ecg_recordings
