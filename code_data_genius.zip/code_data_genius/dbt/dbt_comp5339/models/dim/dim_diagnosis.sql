{{
    config(
        materialized = 'table',
        unique_key = 'diagnosis_code'
    )
}}

SELECT
    diagnosis_code,
    diagnosis_category
FROM {{ ref('staging_diagnosis') }}