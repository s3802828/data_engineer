-- dim_patients.sql
-- Dimension table for patient demographics, enhancing data with cleaning and formatting
{{
    config(
        materialized = 'table',
        unique_key = 'subject_id'
    )
}}

SELECT * 
FROM {{ ref('staging_patients') }}
WHERE subject_id IS NOT NULL
