{{
    config(
        materialized = 'table',
        unique_key = "ed_stay_id || '-' || subject_id || '-' || ecg_no_within_stay"
    )
}}

SELECT
    ed_stay_id,
    subject_id,
    ecg_no_within_stay,
    ed_diagnosis_code
FROM {{ ref('staging_ed_visits') }}
