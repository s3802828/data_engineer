{{
    config(
        materialized = 'table',
        unique_key = "hosp_hadm_id || '-' || subject_id || '-' || ecg_no_within_stay"
    )
}}

SELECT
    hosp_hadm_id,
    subject_id,
    ecg_no_within_stay,
    hospital_diagnosis_code
FROM {{ ref('staging_hospital_admissions') }}