from datetime import timedelta, datetime
import pytz
from airflow import DAG
from airflow.operators.postgres_operator import PostgresOperator

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    'initialize_etl_environment',
    default_args=default_args,
    description='Initialize ETL Environment',
    schedule_interval='@once',
    start_date=datetime(2024, 1, 1, 0, 0, 0, 0, pytz.UTC),
    tags=['init'],
    is_paused_upon_creation=False
)


create_schemas_task = PostgresOperator(
    task_id='create_schemas',
    sql = """
    Create schema if not exists import;
    Create schema if not exists warehouse;
    Create schema if not exists ops;
    Create schema if not exists staging;        
    """,
    dag=dag,
    postgres_conn_id = 'hospital_dw',
    autocommit = True
)

create_registry_table = PostgresOperator(
    task_id='create_registry_table',
    sql = """
    CREATE TABLE IF NOT EXISTS ops.FlatFileLoadRegistry (
        EntryID serial PRIMARY KEY, 
        Filename varchar(255) UNIQUE, 
        Extension varchar(10), 
        LoadDate timestamp,
        Processed boolean, 
        Validated boolean);
        
    """,
    dag=dag,
    postgres_conn_id = 'hospital_dw',
    autocommit = True
)

create_patients_table = PostgresOperator(
    task_id='create_patients_table',
    sql = """
    CREATE TABLE IF NOT EXISTS import.patients(
        subject_id BIGINT PRIMARY KEY,
        gender TEXT,
        anchor_year INT,
        dod TEXT
        );
    """,
    postgres_conn_id='hospital_dw',
    autocommit=True,
    dag=dag
)

create_hospital_admissions_table = PostgresOperator(
    task_id='create_hospital_admissions_table',
    sql = """
    CREATE TABLE IF NOT EXISTS import.hospital_admissions(
        hosp_hadm_id BIGINT,
        subject_id BIGINT REFERENCES import.patients(subject_id),
        ecg_no_within_stay INT,
        hosp_diag_hosp TEXT[],
        PRIMARY KEY (hosp_hadm_id, ecg_no_within_stay, subject_id)
    );
    """,
    postgres_conn_id='hospital_dw',
    autocommit=True,
    dag=dag
)

create_ed_visits_table = PostgresOperator(
    task_id='create_ed_visits_table',
    sql = """
    CREATE TABLE IF NOT EXISTS import.ed_visits(
        ed_stay_id BIGINT,
        subject_id BIGINT REFERENCES import.patients(subject_id),
        ecg_no_within_stay INT,
        ed_diag_ed TEXT[],
        PRIMARY KEY (ed_stay_id, ecg_no_within_stay, subject_id)
    );
    """,
    postgres_conn_id='hospital_dw',
    autocommit=True,
    dag=dag
)

create_ed_hospital_admissions_table = PostgresOperator(
    task_id='create_ed_hospital_admissions_table',
    sql = """
    CREATE TABLE IF NOT EXISTS import.ed_hospital_admissions(
        ed_hadm_id BIGINT,
        ed_stay_id BIGINT,
        subject_id BIGINT,
        ecg_no_within_stay INT,
        ed_diag_hosp TEXT[],
        PRIMARY KEY (ed_hadm_id, ed_stay_id, subject_id),
        FOREIGN KEY (ed_stay_id, ecg_no_within_stay, subject_id) REFERENCES import.ed_visits(ed_stay_id, ecg_no_within_stay, subject_id)
    );
    """,
    postgres_conn_id='hospital_dw',
    autocommit=True,
    dag=dag
)

create_ecg_recordings_table = PostgresOperator(
    task_id='create_ecg_recordings_table',
    sql = """
    CREATE TABLE IF NOT EXISTS import.ecg_recordings(
        study_id BIGINT PRIMARY KEY,
        file_name TEXT,
        ecg_time TIMESTAMP,
        age INT,
        anchor_age INT,
        all_diag_all TEXT[],
        ecg_no_within_stay INT,
        subject_id BIGINT,
        hosp_hadm_id BIGINT,
        ed_hadm_id BIGINT,
        ed_stay_id BIGINT,
        FOREIGN KEY (subject_id) REFERENCES import.patients(subject_id),
        FOREIGN KEY (hosp_hadm_id, ecg_no_within_stay, subject_id) REFERENCES import.hospital_admissions(hosp_hadm_id, ecg_no_within_stay, subject_id),
        FOREIGN KEY (ed_stay_id, ecg_no_within_stay, subject_id) REFERENCES import.ed_visits(ed_stay_id, ecg_no_within_stay, subject_id),
        FOREIGN KEY (ed_hadm_id, ed_stay_id, subject_id) REFERENCES import.ed_hospital_admissions(ed_hadm_id, ed_stay_id, subject_id)
    );
    """,
    postgres_conn_id='hospital_dw',
    autocommit=True,
    dag=dag
)

create_schemas_task >> create_registry_table

create_schemas_task >> create_patients_table >> [create_ed_visits_table, create_hospital_admissions_table] >> create_ed_hospital_admissions_table >> create_ecg_recordings_table
