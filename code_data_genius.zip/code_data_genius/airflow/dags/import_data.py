from datetime import timedelta, datetime
import pytz
import os
import pandas as pd
import glob
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.hooks.postgres_hook import PostgresHook
from airflow.utils.dates import days_ago
from airflow.sensors.external_task import ExternalTaskSensor

# Environment variables for DB connections
AIRFLOW_CONN_HOSPITAL_DW = os.getenv('AIRFLOW_CONN_HOSPITAL_DW')

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    'import_data_data_genius',
    default_args=default_args,
    description='Import Data from CSV File',
    schedule_interval='@daily',
    start_date=days_ago(1),
    is_paused_upon_creation=False
)

# Wait for environment initialization
wait_for_init = ExternalTaskSensor(
    task_id='wait_for_init',
    external_dag_id='initialize_etl_environment',
    execution_date_fn=lambda x: datetime(2024, 1, 1, 0, 0, 0, 0, pytz.UTC),
    timeout=1,
    dag=dag
)

def process_array(x):
    if x is None or x == {} or x == [] or x == "" or (isinstance(x, str) and x.strip() in ['[]', '{}']):
        return None
    if isinstance(x, str):
        items = x.strip('[]').replace("'", "").replace('"', '').split(',')
        return '{' + ','.join(item.strip() for item in items if item.strip()) + '}'
    return x

def load_csv_data():
    csv_directory = '/import/csv'
    pg_hook_dw = PostgresHook(postgres_conn_id='hospital_dw')
    conn_dw = pg_hook_dw.get_conn()
    cursor_dw = conn_dw.cursor()

    for csv_file_path in glob.glob(os.path.join(csv_directory, '*.csv')):
        cursor_dw.execute("SELECT Filename FROM ops.FlatFileLoadRegistry WHERE Filename = %s AND Processed = TRUE", (csv_file_path,))
        result = cursor_dw.fetchone()

        if result:
            print(f"File {csv_file_path} has already been processed. Skipping.")
            return
        
        df = pd.read_csv(csv_file_path)
    
        df['study_id'] = df['study_id'].astype('Int64')
        df['subject_id'] = df['subject_id'].astype('Int64')
        df['anchor_year'] = df['anchor_year'].astype('Int64')
        df['hosp_hadm_id'] = df['hosp_hadm_id'].astype('Int64')
        df['ed_stay_id'] = df['ed_stay_id'].astype('Int64')
        df['ed_hadm_id'] = df['ed_hadm_id'].astype('Int64')
        df['age'] = df['age'].astype('Int64')
        df['anchor_age'] = df['anchor_age'].astype('Int64')
        df['ecg_no_within_stay'] = df['ecg_no_within_stay'].astype('Int64')

        df['ed_diag_ed'] = df['ed_diag_ed'].apply(process_array)
        df['ed_diag_hosp'] = df['ed_diag_hosp'].apply(process_array)
        df['hosp_diag_hosp'] = df['hosp_diag_hosp'].apply(process_array)
        df['all_diag_all'] = df['all_diag_all'].apply(process_array)
        df = df.replace({pd.NA: None})

        # Patients data
        patients_df = df[['subject_id', 'gender', 'anchor_year', 'dod']].drop_duplicates()
        # Hospital Admissions data
        hospital_admissions_df = df[['hosp_hadm_id', 'subject_id', 'ecg_no_within_stay', 'hosp_diag_hosp']].drop_duplicates(subset=['hosp_hadm_id', 'subject_id', 'ecg_no_within_stay']).dropna(subset=['hosp_hadm_id', 'subject_id', 'ecg_no_within_stay'])
        # ED Visits data
        ed_visits_df = df[['ed_stay_id', 'subject_id', 'ecg_no_within_stay', 'ed_diag_ed']].drop_duplicates(subset=['ed_stay_id', 'subject_id', 'ecg_no_within_stay']).dropna(subset=['ed_stay_id', 'subject_id', 'ecg_no_within_stay'])
        # ED Hospital Admissions data
        ed_hosp_df = df[['ed_hadm_id', 'ed_stay_id', 'subject_id', 'ecg_no_within_stay', 'ed_diag_hosp']].drop_duplicates(subset=['ed_hadm_id','ed_stay_id', 'subject_id']).dropna(subset=['ed_hadm_id','ed_stay_id', 'subject_id'])
        # ECG Recordings data
        ecg_recordings_df = df[['study_id', 'file_name', 'ecg_time', 'age', 'anchor_age', 'all_diag_all', 'ecg_no_within_stay', 'subject_id', 'hosp_hadm_id', 'ed_hadm_id', 'ed_stay_id']].drop_duplicates()


        pg_hook_dw.insert_rows(
            table='import.patients',
            rows=patients_df.values.tolist(),
            target_fields=['subject_id', 'gender', 'anchor_year', 'dod']
        )

        pg_hook_dw.insert_rows(
            table='import.hospital_admissions',
            rows=hospital_admissions_df.values.tolist(),
            target_fields=['hosp_hadm_id', 'subject_id', 'ecg_no_within_stay', 'hosp_diag_hosp']
        )

        pg_hook_dw.insert_rows(
            table='import.ed_visits',
            rows=ed_visits_df.values.tolist(),
            target_fields=['ed_stay_id', 'subject_id', 'ecg_no_within_stay', 'ed_diag_ed']
        )

        pg_hook_dw.insert_rows(
            table='import.ed_hospital_admissions',
            rows=ed_hosp_df.values.tolist(),
            target_fields=['ed_hadm_id', 'ed_stay_id', 'subject_id', 'ecg_no_within_stay', 'ed_diag_hosp']
        )

        pg_hook_dw.insert_rows(
            table='import.ecg_recordings',
            rows=ecg_recordings_df.values.tolist(),
            target_fields=['study_id', 'file_name', 'ecg_time', 'age', 'anchor_age', 'all_diag_all', 'ecg_no_within_stay', 'subject_id', 'hosp_hadm_id', 'ed_hadm_id', 'ed_stay_id']
        )


        cursor_dw.execute("INSERT INTO ops.FlatFileLoadRegistry (Filename, Extension, LoadDate, Processed, Validated) VALUES (%s, %s, %s, TRUE, TRUE)",
                    (csv_file_path, 'csv', datetime.now()))
        conn_dw.commit()
        
    cursor_dw.close()
    conn_dw.close()

load_csv_task = PythonOperator(
    task_id='load_csv_data',
    python_callable=load_csv_data,
    dag=dag
)

# Task dependencies
wait_for_init >> load_csv_task