from datetime import timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.utils.dates import days_ago
from airflow.sensors.external_task import ExternalTaskSensor

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email': ['airflow@example.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    'run_dbt',
    default_args=default_args,
    description='Running DBT',
    schedule_interval='@once',
    start_date=days_ago(1),
    is_paused_upon_creation=False
)

wait_for_data = ExternalTaskSensor(
    task_id='wait_for_data',
    external_dag_id='import_data_data_genius',
    execution_date_fn=lambda x: days_ago(1),
    timeout=700,
    dag=dag
)

dbt_deps = BashOperator(
    task_id='dbt_deps',
    bash_command='cd /usr/local/airflow/dbt && /usr/local/bin/dbt deps',
    dag=dag
)

dbt_run = BashOperator(
    task_id='dbt_run',
    bash_command='cd /usr/local/airflow/dbt && /usr/local/bin/dbt run',
    dag=dag
)

dbt_test = BashOperator(
    task_id='dbt_test',
    bash_command='cd /usr/local/airflow/dbt && /usr/local/bin/dbt test',
    dag=dag
)


wait_for_data >> dbt_deps >> dbt_run >> dbt_test
